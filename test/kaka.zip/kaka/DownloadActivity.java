package com.mobilesoftvn.mdictpro;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.mobilesoftvn.lib.applib.AppUtils;
import com.mobilesoftvn.lib.applib.HTTPDownloader;
import com.mobilesoftvn.mdictpro.base.GUIUtils;
import com.mobilesoftvn.mdictpro.base.Utils;
import com.mobilesoftvn.mdictpro.lib.DataInfo;
import com.mobilesoftvn.mdictpro.lib.DataInfo.DataStatus;
import com.mobilesoftvn.mdictpro.lib.DataInfo.DownloadStatus;
import com.mobilesoftvn.mdictpro.lib.DictDownloadManager;
import com.mobilesoftvn.mdictpro.lib.DictInfoEx;

@SuppressLint("UseSparseArrays")
public class DownloadActivity extends BaseActivity {
	private ArrayList<DataInfo> mDataInfos = null;
	private ListView listView = null;
	private DownloadAdapter listViewAdapter = null;	
	private DictDownloadManager mDownloadManager = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_download);
		
		// Khoi tao lop quan ly download du lieu
		String dataDir = null;
		ArrayList<String> dataPaths = appInfo.getDataPaths();
		if (dataPaths.size()>0) {
			dataDir = dataPaths.get(0);
		}
		mDownloadManager = new DictDownloadManager(dataDir, new DictDownloadManager.DownloadEventLister() {
			@Override
			public void onDownloading(DataInfo data, long sizeDownloaded) {
				refreshListViewOnUIThread();
			}
			
			@Override
			public void onDownloadStarted(DataInfo data, long fileSize) {
				refreshListViewOnUIThread();
			}
			
			@Override
			public void onDownloadCompleted(final DataInfo data, int status) {
				refreshListViewOnUIThread();
				if (status!=HTTPDownloader.HTTPDownloaderStatus.OK) {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							String msg = getString(R.string.activity_download_dictdata_error);
							msg = String.format(msg, data.getName());
							GUIUtils.showToast(DownloadActivity.this, msg);
						}
					});
				}
			}
		});
		
		// Thiet lap su kien cho ListView
		listView = (ListView) findViewById(R.id.listviewDownload);
		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
				final int idx = arg2;
				if (mDataInfos==null || idx<0 || idx>=mDataInfos.size()) return;
				
				final DataInfo data = mDataInfos.get(idx);
				String descriptionFormat = getString(R.string.activity_download_data_description);
				String description = String.format(descriptionFormat,
						data.getVersion(),
						data.getWordNum(),
						MDictProApp.getDisplayDateStr(data.getPublicDate()),
						Utils.getSizeDisplay(data.getDataSize()),
						getStatusStr(data)
				);
				String guider = getStatusGuideStr(data);
				GUIUtils.showDownloadConfirmDialog(DownloadActivity.this, data.getName(), description, guider, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
						
						// Thuc hien download du lieu
						mDownloadManager.downloadData(data);
					}
				});
			}
		});
		
		Button btnRefresh = (Button) findViewById(R.id.btnRefresh);
		btnRefresh.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String title = getString(R.string.activity_download_datainfo_title);
				String message = getString(R.string.activity_download_datainfo_message);
				GUIUtils.showConfirmDialog(DownloadActivity.this, title, message, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
						mDownloadManager.cancelDownloadAll();
						downloadDataInfoFile();
					}
				});
			}
		});
		btnRefresh.setOnLongClickListener(new OnLongClickListener() {
			@Override
			public boolean onLongClick(View v) {
				GUIUtils.showToast(DownloadActivity.this, R.string.button_downloaddictinfo_guide);
				return true;
			}
		});
		
		// Load du lieu hien thi tren ListView
		loadDataInfo();
		
		// Tu dong download du lieu moi
		if (AppUtils.hasNetworkConnection(this)) {
			// Thuc hien download file danh sach du lieu
			downloadDataInfoFile();
		}
		else {
			GUIUtils.showToast(this, R.string.activity_download_no_network_connection);
		}
	}
	
	// Download tep XML chua thong tin du lieu
	private void downloadDataInfoFile() {
		(new DownloadDataInfoTask()).execute();
	}
	
	/**
	 * Ham giai phong tai nguyen
	 */
	protected void onDestroy() {
		// Xoa cac tai nguyen can thiet su dung cho download
		mDownloadManager.cancelDownloadAll();
		super.onDestroy();
	};
	
	/**
	 * Bat su kien dong hop thoai
	 */
	public void onBackPressed() {
		if (mDownloadManager.isDownloading()) {
			GUIUtils.showConfirmDialog(this, R.string.activity_download_close_warning, R.string.activity_download_close_message, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
					mDownloadManager.cancelDownloadAll();
					DownloadActivity.super.onBackPressed();
				}
			});
			return;
		}
		super.onBackPressed();
	};
	
	/**
	 * Lay trang thai du lieu dang xau
	 */
	private String getStatusStr(final DataInfo data) {
		String str = "";
		int downloadStatus = data.getDownloadStatus();
		if (downloadStatus!=DownloadStatus.STATUS_NONE) {
			switch (downloadStatus) {
				case DownloadStatus.STATUS_PENDING:
					str = DownloadActivity.this.getString(R.string.download_status_pending);
					break;
				case DownloadStatus.STATUS_DOWNLOADING:
					String statusDownloadingFormat = DownloadActivity.this.getString(R.string.download_status_downloading);
					str = String.format(statusDownloadingFormat, Utils.getSizeDisplay(data.getDownloadedSize()), Utils.getSizeDisplay(data.getDataSize())); 
					
					break;
				case DownloadStatus.STATUS_SUCCESSFUL:
					str = DownloadActivity.this.getString(R.string.download_status_download_sucess);
					break;
				case DownloadStatus.STATUS_FAILED:
					str = DownloadActivity.this.getString(R.string.download_status_download_error);
					break;
			}
		}
		else {
			int dataStatus = data.getDataStatus();
			switch (dataStatus) {
				case DataStatus.DATA_NOT_FOUND:
					str = DownloadActivity.this.getString(R.string.data_status_not_found);
					break;
				case DataStatus.DATA_EXISTED:
					str = DownloadActivity.this.getString(R.string.data_status_existed);
					break;
				case DataStatus.DATA_OLD_VERSION:
					str = DownloadActivity.this.getString(R.string.data_status_old_version);
					break;
			}
		}
		return str;
	}
	
	/**
	 * Lay trang thai du lieu dang xau
	 */
	private String getStatusGuideStr(final DataInfo data) {
		String guide = null;
		int dataStatus = data.getDataStatus();
		int downloadStatus = data.getDownloadStatus();
		if (downloadStatus==DownloadStatus.STATUS_NONE) {
			if (dataStatus==DataStatus.DATA_NOT_FOUND) {
				guide = getString(R.string.activity_download_dictdata_message);
			}
			else if (dataStatus==DataStatus.DATA_OLD_VERSION) {
				guide = getString(R.string.activity_update_dictdata_message);
			}
		}
		else if (downloadStatus==DownloadStatus.STATUS_FAILED) {
			guide = getString(R.string.activity_redownload_dictdata_message);
		}
		return guide;
	}

	/**
	 * Load thong tin du lieu tu tep
	 */
	private boolean loadDataInfo() {
		ArrayList<String> dataPaths = appInfo.getDataPaths();		
		boolean ret = false;
		for (int i=0; i<dataPaths.size(); i++) {
			String filename = dataPaths.get(i);
			filename += "/" + MDictProApp.DATA_INFO_FILENAME;
			mDataInfos = getDataInfos(filename);
			if (mDataInfos!=null) {
				ret = true;
				break;
			}
		}
		if (ret) {
			updateDataToListView();
		}
		
		return ret;
	}
	
	/**
	 * Cap nhat thong tin vao ListView
	 */
	private void updateDataToListView() {
		if (mDataInfos==null) return;
		
		if (listViewAdapter==null) {
			listViewAdapter = new DownloadAdapter(mDataInfos);
			listView.setAdapter(listViewAdapter);
		}
		else {
			listViewAdapter.setDataInfos(mDataInfos);
			listViewAdapter.notifyDataSetChanged();
		}
	}
	
	/**
	 * 
	 */
	private void refreshListViewOnUIThread() {
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				if (listViewAdapter!=null)
					listViewAdapter.notifyDataSetChanged();
			}
		});
	}
	
	/**
	 * Lay thong tin lien quan du lieu
	 */
	private ArrayList<DataInfo> getDataInfos(String filename) {
		ArrayList<DataInfo> arrDatas = new ArrayList<DataInfo>();

		DocumentBuilderFactory docBuilderFactory = null;
	    DocumentBuilder docBuilder = null;
	    File fileXML = null;
	    Document doc = null;
		try {
			// Mo file o dang XML
            docBuilderFactory = DocumentBuilderFactory.newInstance();
            docBuilder = docBuilderFactory.newDocumentBuilder();
            fileXML = new File(filename);
            doc = docBuilder.parse (fileXML);
            doc.getDocumentElement().normalize();      // Normalize text representation
            
            // Doc du lieu
            NodeList dataNodes = doc.getElementsByTagName("data");
	        int total = dataNodes.getLength();
	        for(int i=0; i<total; i++) {
	            Node node = dataNodes.item(i);
	            NodeList childNodes = node.getChildNodes();
	            DataInfo dataInfo = new DataInfo();
	            for (int j=0; j<childNodes.getLength(); j++) {
	            	Node childNode = childNodes.item(j);
	            	if (childNode.getNodeType()==Node.ELEMENT_NODE) {
		            	String name = childNode.getNodeName();
		            	String value = childNode.getTextContent();
		            	if ("id".equalsIgnoreCase(name)) {
		            		int id = 0;
		            		try {
		            			id = Integer.parseInt(value);
		            		} catch (Exception e) {}
		            		dataInfo.setId(id);
		            	}
		            	else if ("name".equalsIgnoreCase(name)) {
		            		dataInfo.setName(value);
		            	}
		            	else if ("version".equalsIgnoreCase(name)) {
		            		dataInfo.setVersion(value);
		            	}
						else if ("word-num".equalsIgnoreCase(name)) {
							int wordNum = 0;
		            		try {
		            			wordNum = Integer.parseInt(value);
		            		} catch (Exception e) {}
							dataInfo.setWordNum(wordNum);
						}
						else if ("size".equalsIgnoreCase(name)) {
							long size = 0;
		            		try {
		            			size = Long.parseLong(value);
		            		} catch (Exception e) {}
							dataInfo.setDataSize(size);
						}
						else if ("public-date".equalsIgnoreCase(name)) {
							dataInfo.setPublicDate(MDictProApp.getSourceDate(value));
						}
						else if ("link".equalsIgnoreCase(name)) {
							dataInfo.setDownloadLink(value);
						}
	            	}
	            }
	            if (dataInfo.isValid()) {
	            	arrDatas.add(dataInfo);
	            }
	        }
        }
        catch (IOException e) {
            MDictProApp.LogE("Unable to open file '" + filename + "'");
            e.printStackTrace();
        }
        catch (Exception e) {
        	MDictProApp.LogE("Error to parse xml file '" + filename + "'");
        	e.printStackTrace();
        }
		finally {
			doc = null;
	        docBuilder = null;
	        docBuilderFactory = null;
	        fileXML = null;
		}
		
		if (arrDatas.size()==0) {
			arrDatas = null;
		}
		else {
			// Kiem tra trang thai du lieu
			for (int i=0; i<arrDatas.size(); i++) {
				DataInfo data = arrDatas.get(i);
				DictInfoEx d = appInfo.getConfigManager().getDict(data.getId());
				if (d!=null) {
					int status =  DataStatus.DATA_EXISTED;
					if (!d.checkVersion(data.getVersion()))
						status = DataStatus.DATA_OLD_VERSION;
					data.setDataStatus(status);
				}
			}
		}
		
		return arrDatas;
	}
	
	/**
	 * Lop adapter cho Download Listview
	 */
	private class DownloadAdapter extends BaseAdapter {
		private ArrayList<DataInfo> mDataInfos;
		private String mInfoFormat, mStatusFormat;
		
		public DownloadAdapter(ArrayList<DataInfo> dataInfos) {
			setDataInfos(dataInfos);
			
			// Lay xau dinh dinh dang hien thi du lieu
			mInfoFormat = getString(R.string.activity_download_data_info);
	        mStatusFormat = getString(R.string.activity_download_data_status);
		}
		
		public void setDataInfos(ArrayList<DataInfo> dataInfos) {
			mDataInfos = dataInfos;
			if (mDataInfos==null) {
				mDataInfos = new ArrayList<DataInfo>();
			}
		}

		public int getCount() {
            return mDataInfos.size();
        }

        public Object getItem(int arg0) {
            return mDataInfos.get(arg0);
        }

        public long getItemId(int position) {
        	return mDataInfos.get(position).getId();
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            // Tao view cho row
        	View row = convertView;
        	if (row==null) {
        		LayoutInflater inflater = getLayoutInflater();
        		row = inflater.inflate(R.layout.listview_dictdata_item, parent, false);
        	}
            
        	// Lay du lieu tuong ung voi row nay
            DataInfo data = mDataInfos.get(position);
            
            // Thiet lap thong tin title
            TextView viewTitle = (TextView) row.findViewById(R.id.sectionlist_item_title);
            viewTitle.setText(data.getName());
            
            // Thiet lap thong tin Info
            String info = String.format(mInfoFormat, data.getWordNum(), data.getVersion(), MDictProApp.getDisplayDateStr(data.getPublicDate()));
            TextView viewInfo = (TextView) row.findViewById(R.id.sectionlist_item_info);
            viewInfo.setText(info);
            
            // Thiet lap thong tin Status
            String status = String.format(mStatusFormat, getStatusStr(data));
            TextView viewStatus = (TextView) row.findViewById(R.id.sectionlist_item_status);
            viewStatus.setText(status);
            
            return row;
        }
	}
	
	/**
	 * Lop thuc hien download tep XML chua thong tin cac tu dien
	 */
	private class DownloadDataInfoTask extends AsyncTask<Void, Void, Boolean> {
		private ProgressDialog mWaitingDialog = null;
		private int mDownloadStatus = HTTPDownloader.HTTPDownloaderStatus.OK;
		
    	// Ham khoi tao
    	public DownloadDataInfoTask() {
    	}
    	
    	@Override
    	protected void onPreExecute() {
    		mDownloadStatus = HTTPDownloader.HTTPDownloaderStatus.OK;
    		String message = getString(R.string.activity_download_downloading);
    		mWaitingDialog = GUIUtils.showWaitingDialog(DownloadActivity.this, message);
			mWaitingDialog.setCancelable(false);
    	}
    	
    	@Override
    	protected Boolean doInBackground(Void... params) {
    		HTTPDownloader httpDownloader = new HTTPDownloader();
    		httpDownloader.autoDeleteWhenError(false);
    		String strSavedPath = "";
    		ArrayList<String> dataPaths = appInfo.getDataPaths();
    		if (dataPaths.size()>0) {
    			strSavedPath += dataPaths.get(0);
    		}
    		strSavedPath += "/" + MDictProApp.DATA_INFO_FILENAME;
    		httpDownloader.downloadData( MDictProApp.DATA_INFO_URL, strSavedPath, new HTTPDownloader.HTTPDownloaderListener() {
				@Override
				public void onDownloading(final long downloadedSize) {}
				
				@Override
				public void onDownloadStarted(final long fileSize) {}
				
				@Override
				public void onDownloadCompleted(final int status) {
					mDownloadStatus = status;
				}
			});
    		
    		return (mDownloadStatus==HTTPDownloader.HTTPDownloaderStatus.OK);
    	}

    	@Override
    	protected void onPostExecute(Boolean isSucessed) {
    		if (mWaitingDialog!=null) {
    			mWaitingDialog.dismiss();
    			mWaitingDialog = null;
			}
    		
    		if (isSucessed)
				loadDataInfo();
    		else {
    			String title = getString(R.string.activity_download_datainfo_title);
				String message = getString(R.string.activity_redownload_datainfo_message);
				GUIUtils.showConfirmDialog(DownloadActivity.this, title, message, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
						mDownloadManager.cancelDownloadAll();
						downloadDataInfoFile();
					}
				});
    		}
    	}
    }
}

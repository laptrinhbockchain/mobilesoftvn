package com.mobilesoftvn.lib.applib;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.http.util.ByteArrayBuffer;

public class HTTPDownloader {
	private static int DATA_STREAM_LENGTH = 100*1024;
	private boolean isUserStopped = false;
	private boolean isAutoDeleteWhenError = true;
	
	/**
	 * Download du lieu luu vao mang byte
	 * Chi su dung voi du lieu nho 20M (Chinh xac co the 25M)
	 */
	public ByteArrayBuffer downloadData(String link, HTTPDownloaderListener listener) {
		isUserStopped = false;
		ByteArrayBuffer out = null;
		link = standardLink(link);

		HttpURLConnection connection = null;
		int statusResponseCode = HttpURLConnection.HTTP_OK;
		int status = HTTPDownloaderStatus.OK;
        try {
            // Thuc hien mo ket noi toi server de lay du lieu
            connection = (HttpURLConnection) new URL(link).openConnection();
            connection.connect();
            if (listener!=null) {
            	listener.onDownloadStarted(connection.getContentLength());
            }

            // Lay du lieu
            statusResponseCode = connection.getResponseCode();
            if (statusResponseCode==HttpURLConnection.HTTP_OK) {
            	out = new ByteArrayBuffer(DATA_STREAM_LENGTH);
            	InputStream iStrm = connection.getInputStream();
                int totalLength = 0;
                byte[] buffer = new byte[DATA_STREAM_LENGTH];
                int len = 0;
                while ((len = iStrm.read(buffer)) != -1 ) {
                	if (isUserStopped) {
                		status = HTTPDownloaderStatus.USER_STOPPED;
                		break;
                	}
                	out.append(buffer, 0, len);
                    totalLength += len;
                    if (listener!=null) {
                    	listener.onDownloading(totalLength);
                    }
                }
                buffer = null;
                iStrm.close();
            }
            else {
            	status = HTTPDownloaderStatus.SERVER_ERROR;
            }
        }
        catch (Exception e) {
        	e.printStackTrace();
            if (statusResponseCode==HttpURLConnection.HTTP_FORBIDDEN || statusResponseCode==HttpURLConnection.HTTP_NOT_FOUND) {
            	status = HTTPDownloaderStatus.NETWORK_ERROR;
            }
            else if (statusResponseCode!=HTTPDownloaderStatus.OK) {
            	status = HTTPDownloaderStatus.SERVER_ERROR;
            }
            else {
            	status = HTTPDownloaderStatus.FILE_SAVE_ERROR;
            }
        }
        finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        if (listener!=null) {
        	listener.onDownloadCompleted(status);
        }
        return out;
	}
	
	/**
	 * Download du lieu va luu vao tep
	 */
	public int downloadData(String link, String savePath, HTTPDownloaderListener listener) {
		isUserStopped = false;
		link = standardLink(link);

		HttpURLConnection connection = null;
		FileOutputStream out = null;
		InputStream iStrm = null;
		int statusResponseCode = HttpURLConnection.HTTP_OK;
		int status = HTTPDownloaderStatus.OK;
        try {
            // Thuc hien mo ket noi toi server de lay du lieu
            connection = (HttpURLConnection) new URL(link).openConnection();
            connection.connect();
            if (listener!=null) {
            	listener.onDownloadStarted(connection.getContentLength());
            }

            // Lay du lieu
            statusResponseCode = connection.getResponseCode();
            if (statusResponseCode==HttpURLConnection.HTTP_OK) {
            	out = new FileOutputStream(savePath);
            	iStrm = connection.getInputStream();
                int totalLength = 0;
                byte[] buffer = new byte[DATA_STREAM_LENGTH];
                int len = 0;
                while ((len = iStrm.read(buffer)) != -1 ) {
                	if (isUserStopped) {
                		status = HTTPDownloaderStatus.USER_STOPPED;
                		break;
                	}
                	out.write(buffer, 0, len);
                    totalLength += len;
                    if (listener!=null) {
                    	listener.onDownloading(totalLength);
                    }
                }
                buffer = null;
            }
            else {
            	status = HTTPDownloaderStatus.SERVER_ERROR;
            }
        }
        catch (Exception e) {
        	e.printStackTrace();
            if (statusResponseCode==HttpURLConnection.HTTP_FORBIDDEN || statusResponseCode==HttpURLConnection.HTTP_NOT_FOUND) {
            	status = HTTPDownloaderStatus.NETWORK_ERROR;
            }
            else if (statusResponseCode!=HTTPDownloaderStatus.OK) {
            	status = HTTPDownloaderStatus.SERVER_ERROR;
            }
            else {
            	status = HTTPDownloaderStatus.FILE_SAVE_ERROR;
            }
        }
        finally {
        	if (iStrm!=null) {
        		try {iStrm.close();} catch(Exception e){}
        		iStrm = null;
        	}
        	if (out!=null) {
        		try {out.close();} catch(Exception e){}
        		out = null;
        	}
            if (connection != null) {
                connection.disconnect();
                connection = null;
            }
        }
        if (isAutoDeleteWhenError && status!=HTTPDownloaderStatus.OK && savePath!=null) {
        	// Truong hop loi thi xoa file loi
        	File f = new File(savePath);
        	if (f.exists()) {
        		f.delete();
        	}
        }
        if (listener!=null) {
        	listener.onDownloadCompleted(status);
        }
        return status;
	}
	
	public void stop() {
		isUserStopped = true;
	}
	
	public void autoDeleteWhenError(boolean autoDelete) {
		isAutoDeleteWhenError = autoDelete;
	}
	
	private String standardLink(String link) {
		String ret = link;
		if (ret!=null) {
			ret = link.replaceAll(" ", "%20");
		}
		return ret;
	}
	
	public static class HTTPDownloaderStatus {
		public static final int OK = 0;
		public static final int SERVER_ERROR = 1;
		public static final int NETWORK_ERROR = 2;
		public static final int USER_STOPPED = 3;
		public static final int FILE_SAVE_ERROR = 4;
		
		public static String toString(int status) {
			String ret = "Unknown error";
			switch (status) {
				case OK:
					ret = "Sucessful";
					break;
				case SERVER_ERROR:
					ret = "Server error";
					break;
				case NETWORK_ERROR:
					ret = "Network error";
					break;
				case USER_STOPPED:
					ret = "User stopped";
					break;
				case FILE_SAVE_ERROR:
					ret = "Save file error";
					break;
			}
			return ret;
		}
	}
	
	public interface HTTPDownloaderListener {
		public void onDownloadStarted(long fileSize);
		public void onDownloading(long downloadedSize);
		public void onDownloadCompleted(int status);
	}
}
